package com.neu.biz;

import com.neu.entity.UserSeen;

import java.util.List;

public interface UserSeenBiz {
    public List<UserSeen> findUserSeen(int index, int size);
        List<UserSeen> getAllUserSeenByUname (String uname);
}
