package com.neu.biz.impl;

import com.neu.biz.UserSeenBiz;
import com.neu.entity.UserSeen;
import com.neu.mapper.UserSeenMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("userSeenBiz")
public class UserSeenBizImpl implements UserSeenBiz {
    @Autowired
    private UserSeenMapper userSeenMapper;
    @Override
    public List<UserSeen> findUserSeen(int index, int size) {
        Map<String,Object> map = new HashMap<String,Object>();
        int pageNo = (index - 1) * size;
        map.put("index", pageNo);
        map.put("size", size);
        List<UserSeen> list = userSeenMapper.findUserSeen(map);
        return list;
    }

    @Override
    public List<UserSeen> getAllUserSeenByUname(String uname) {
        return userSeenMapper.getAllUserSeenByUname(uname);
    }
}
