package com.neu.mapper;

import com.neu.entity.UserSeen;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

@Mapper
public interface UserSeenMapper {
    public List<UserSeen> findUserSeen(Map<String,Object> map);

    List<UserSeen> getAllUserSeen();
    // 当前用户下所有已看电影列表
    List<UserSeen> getAllUserSeenByUname(String uname);
}
