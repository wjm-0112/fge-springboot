package com.neu.controller;

import com.neu.biz.UserSeenBiz;
import com.neu.entity.UserCollection;
import com.neu.entity.UserSeen;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("userSeen")
@CrossOrigin(origins = "http://localhost:8080", maxAge = 3600)
public class UserSeenController {
    @Autowired
    private UserSeenBiz userSeenBiz;

    @RequestMapping(value = "/findUserSeen")
    @ResponseBody
    public Map<String,Object> findUserSeen(Integer index) {
        if (index == null) index = 1;
        int size = 5;
        List<UserSeen> list = userSeenBiz.findUserSeen(index, size);
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("list", list);
        map.put("index", index);
    	return map;
    }

    @RequestMapping(value = "/getAllUserCollectionByUname")
    @ResponseBody
    public List<UserSeen> getAllUserCollectionByUname(String uname) {
        List<UserSeen> list = userSeenBiz.getAllUserSeenByUname(uname);
        return list;
    }
}
