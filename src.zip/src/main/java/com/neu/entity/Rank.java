package com.neu.entity;

public class Rank {
    private int rid;
    private String name;
    private Movie score = new Movie();
    private Movie collection = new Movie();

    public Rank(){}

    public Rank(int rid, String name, Movie score, Movie collection) {
		this.rid = rid;
		this.name = name;
		this.score = score;
		this.collection = collection;
	}

    public int getRid() {
        return rid;
    }

    public void setRid(int rid) {
        this.rid = rid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Movie getScore() {
        return score;
    }

    public void setScore(Movie score) {
        this.score = score;
    }

    public Movie getCollection() {
        return collection;
    }

    public void setCollection(Movie collection) {
        this.collection = collection;
    }
}
