package com.neu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FgeSpringbootApplication {

    public static void main(String[] args) {
        SpringApplication.run(FgeSpringbootApplication.class, args);
    }

}
