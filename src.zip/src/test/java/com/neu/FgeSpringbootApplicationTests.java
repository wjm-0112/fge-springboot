package com.neu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FgeSpringbootApplicationTests {

    @Test
    void contextLoads() {
    }

}
